package net.uglobal.swiftvalidator.xml.beans;

import java.util.ArrayList;
import java.util.List;



/*
 * <field id="1" tag="16R" status="M" repetitive="N" repetitiveStart="Y" repetitiveEnd="Y">
 *     <qualifier>
 *         <value></value>
 *         <format></format>
 *     </qualifier>
 *     <genericFieldName></genericFieldName>
 *     <detailedFieldName>Start of Block</detailedFieldName>
 *     <content>
 *         <value>GENL</value>
 *         <format></format>
 *     </content>
 *     <options>
 *         <option name="A">
 *             <format>:4!c//8!n</format>
 *         </option>
 *         <option name="C">
 *             <format>:4!c//8!n6!n</format>
 *         </option>
 *         <option name="C">
 *             <format>:4!c//8!n6!n[.3][/[N]2!n[2!n]]</format>
 *         </option>
 *     </options>
 * </field> 
 */

public class Field implements XmlBean {
	private Integer sequenceId;
	private String sequenceShortName;
	private Integer id;
	private String tag;
	private Status status;
	private Boolean repetitive;
	private Boolean repetitiveStart;
	private Boolean repetitiveEnd;
	private Boolean firstOfSequence;
	private Boolean lastOfSequence;
	private Qualifier qualifier;

	private GenericFieldName genericFieldName;
	private DetailedFieldName detailedFieldName;
	private Content content;

	private Options options;

	private List<Field> allowedFollowByFields;

	//	private List<Integer> allowedFollowByFieldIds;
	//	private List<String> allowedFollowByFieldNames;

	public List<Field> getAllowedFollowByFields() {
		return this.allowedFollowByFields;
	}

	public void setAllowedFollowByFields(List<Field> fields) {
		this.allowedFollowByFields = fields;
	}

	//	public List<String> getAllowedFollowByFieldNames() {
	//		return this.allowedFollowByFieldNames;
	//	}
	//
	//	public void setAllowedFollowByFieldNames(List<String> allowedFollowByFieldNames) {
	//		this.allowedFollowByFieldNames = allowedFollowByFieldNames;
	//	}
	//
	//	public List<Integer> getAllowedFollowByFieldIds() {
	//		return this.allowedFollowByFieldIds;
	//	}
	//
	//	public void setAllowedFollowByFieldIds(List<Integer> allowedFollowByFieldIds) {
	//		this.allowedFollowByFieldIds = allowedFollowByFieldIds;
	//	}
	//
	//	public void addAllowedFollowByFieldId(Integer fieldId) {
	//		this.allowedFollowByFieldIds.add(fieldId);
	//	}

	public Integer getSequenceId() {
		return sequenceId;
	}

	public void setSequenceId(Integer sequenceId) {
		this.sequenceId = sequenceId;
	}

	public String getSequenceShortName() {
		return sequenceShortName;
	}

	public void setSequenceShortName(String sequenceShortName) {
		this.sequenceShortName = sequenceShortName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Boolean getRepetitive() {
		return repetitive;
	}

	public void setRepetitive(Boolean repetitive) {
		this.repetitive = repetitive;
	}

	public Boolean getRepetitiveStart() {
		return repetitiveStart;
	}

	public void setRepetitiveStart(Boolean repetitiveStart) {
		this.repetitiveStart = repetitiveStart;
	}

	public Boolean getFirstOfSequence() {
		return firstOfSequence;
	}

	public void setFirstOfSequence(Boolean firstOfSequence) {
		this.firstOfSequence = firstOfSequence;
	}

	public Boolean getLastOfSequence() {
		return lastOfSequence;
	}

	public void setLastOfSequence(Boolean lastOfSequence) {
		this.lastOfSequence = lastOfSequence;
	}

	public Boolean getRepetitiveEnd() {
		return repetitiveEnd;
	}

	public void setRepetitiveEnd(Boolean repetitiveEnd) {
		this.repetitiveEnd = repetitiveEnd;
	}

	public Qualifier getQualifier() {
		return qualifier;
	}

	public void setQualifier(Qualifier qualifier) {
		this.qualifier = qualifier;
	}

	public GenericFieldName getGenericFieldName() {
		return genericFieldName;
	}

	public void setGenericFieldName(GenericFieldName genericFieldName) {
		this.genericFieldName = genericFieldName;
	}

	public DetailedFieldName getDetailedFieldName() {
		return detailedFieldName;
	}

	public void setDetailedFieldName(DetailedFieldName detailedFieldName) {
		this.detailedFieldName = detailedFieldName;
	}

	public Content getContent() {
		return content;
	}

	public void setContent(Content content) {
		this.content = content;
	}

	public Options getOptions() {
		return options;
	}

	public void setOptions(Options options) {
		this.options = options;
	}

	public List<String> getFullOptionNames() {
		if (getOptions() != null && getOptions().getOptionList() != null && getOptions().getOptionList().size() > 0) {
			List<String> fullOptionNames = new ArrayList<String>();
			String tagPrefix = getTagPrefix();
			for (Option option : getOptions().getOptionList()) {
				option.getName();
				fullOptionNames.add(tagPrefix + option.getName());
			}
			return fullOptionNames;
		}
		return null;
	}

	private String getTagPrefix() {
		int i = 0;
		for (Character c : getTag().toCharArray()) {
			if (!Character.isDigit(c)) {
				break;
			}
			i++;
		}
		return tag.substring(0, i);
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[id=").append(getId());
		sb.append(", sequenceId=").append(getSequenceId());
		sb.append(", sequenceShortName=").append(getSequenceShortName());
		sb.append(", tag=").append(getTag());
		sb.append(", status=").append(getStatus().getText());
		sb.append(", repetitive=").append(getRepetitive());
		sb.append(", repetitiveStart=").append(getRepetitiveStart());
		sb.append(", repetitiveEnd=").append(getRepetitiveEnd());
		sb.append(", genericFieldName=").append(getGenericFieldName());
		sb.append(", detailedFieldName=").append(getDetailedFieldName());
		sb.append(", content=").append(getContent());
		sb.append(", options=").append(getOptions());
		sb.append(", qualifier=").append(getQualifier());

		List<Field> allowedFollowByFields = getAllowedFollowByFields();
		StringBuilder sb2 = new StringBuilder();
		if (allowedFollowByFields != null) {
			for (Field f : allowedFollowByFields) {
				sb2.append(f.getId()).append(", ");
			}
		}
		sb.append(", allowedFollowByFields=").append(sb2.toString());
		sb.append("]");
		return sb.toString();
	}

	// -- 
	//	public net.uglobal.swiftvalidator.swift.field.Field16R buildField16R(String validateData) {
	//		return new Field16R(validateData, this);
	//	}

	// *************************** IMPORTANT ***********************************
	// DO NOT REMOVE any lines below.  They are auto generated by code generator
	// *************************************************************************
	// %%%%%BEGIN%%%%%   
	// %%%%%END%%%%%
}
