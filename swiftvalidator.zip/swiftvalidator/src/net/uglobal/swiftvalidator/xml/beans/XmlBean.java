package net.uglobal.swiftvalidator.xml.beans;

public interface XmlBean {

}
