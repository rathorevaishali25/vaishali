
package net.uglobal.swiftvalidator.swift.field;



/**
 * Field format : (chequeReferenceNumber)
 * 
 * AUTO GENERATED - DO NOT HAND MODIFY
 * Generated on Thu Dec 26 13:33:30 IST 2019
 * 
 */
public class Field21E
    extends net.uglobal.swiftvalidator.swift.field.Field
{


    public Field21E(String validateData, net.uglobal.swiftvalidator.xml.beans.Field xmlField) {
        super(validateData, xmlField);
    }

    @Override
    protected void parse() {
        addComponents(net.uglobal.swiftvalidator.swift.field.FieldComponentParseUtil.parse(validateData, getContentFormat()));
    }

    public String getChequeReferenceNumber() {
        return getComponent1();
    }

    public String toString() {
        return (new StringBuilder()).append("[" ).append( "chequeReferenceNumber=" + getComponent1() ).append( "]").toString();
    }

}
