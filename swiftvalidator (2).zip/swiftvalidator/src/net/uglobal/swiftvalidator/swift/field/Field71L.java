
package net.uglobal.swiftvalidator.swift.field;



/**
 * Field format : (currency)(amount)
 * 
 * AUTO GENERATED - DO NOT HAND MODIFY
 * Generated on Thu Dec 26 13:33:33 IST 2019
 * 
 */
public class Field71L
    extends net.uglobal.swiftvalidator.swift.field.Field
{


    public Field71L(String validateData, net.uglobal.swiftvalidator.xml.beans.Field xmlField) {
        super(validateData, xmlField);
    }

    @Override
    protected void parse() {
        addComponents(net.uglobal.swiftvalidator.swift.field.FieldComponentParseUtil.parse(validateData, getContentFormat()));
    }

    public String getCurrency() {
        return getComponent1();
    }

    public String getAmount() {
        return getComponent2();
    }

    public String toString() {
        return (new StringBuilder()).append("[" ).append( "currency=" + getComponent1()).append( ", amount=" + getComponent2() ).append( "]").toString();
    }

}
