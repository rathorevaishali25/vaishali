package net.uglobal.swiftvalidator.validator;

public enum ValidationErrorCode {
	T89, UNKNOWN;
}
