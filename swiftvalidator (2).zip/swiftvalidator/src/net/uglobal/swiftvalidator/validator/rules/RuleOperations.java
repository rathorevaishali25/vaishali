package net.uglobal.swiftvalidator.validator.rules;

import net.uglobal.swiftvalidator.xml.beans.MTMessage;

public class RuleOperations {
	protected static void test(MTMessage mtMessage) {

	}
}
