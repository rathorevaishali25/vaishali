package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterRCharacterSet extends CharacterSet {
	public UpperCaseLetterRCharacterSet() {
		characterSet.add('R');
	}
}
