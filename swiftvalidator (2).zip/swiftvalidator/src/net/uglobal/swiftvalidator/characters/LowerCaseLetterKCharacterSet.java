package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterKCharacterSet extends CharacterSet {
	public LowerCaseLetterKCharacterSet() {
		characterSet.add('k');
	}
}
