package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterWCharacterSet extends CharacterSet {
	public LowerCaseLetterWCharacterSet() {
		characterSet.add('w');
	}
}
