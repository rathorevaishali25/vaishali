package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterZCharacterSet extends CharacterSet {
	public LowerCaseLetterZCharacterSet() {
		characterSet.add('z');
	}
}
