package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterYCharacterSet extends CharacterSet {
	public UpperCaseLetterYCharacterSet() {
		characterSet.add('Y');
	}
}
