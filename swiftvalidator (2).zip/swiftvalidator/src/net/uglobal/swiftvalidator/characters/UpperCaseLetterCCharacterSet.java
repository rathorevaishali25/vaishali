package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterCCharacterSet extends CharacterSet {
	public UpperCaseLetterCCharacterSet() {
		characterSet.add('C');
	}
}
