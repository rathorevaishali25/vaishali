package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterTCharacterSet extends CharacterSet {
	public LowerCaseLetterTCharacterSet() {
		characterSet.add('t');
	}
}
