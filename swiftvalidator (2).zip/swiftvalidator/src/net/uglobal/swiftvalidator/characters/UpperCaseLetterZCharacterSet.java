package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterZCharacterSet extends CharacterSet {
	public UpperCaseLetterZCharacterSet() {
		characterSet.add('Z');
	}
}
