package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterGCharacterSet extends CharacterSet {
	public UpperCaseLetterGCharacterSet() {
		characterSet.add('G');
	}
}
