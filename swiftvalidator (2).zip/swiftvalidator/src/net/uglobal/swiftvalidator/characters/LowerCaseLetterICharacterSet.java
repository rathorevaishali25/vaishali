package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterICharacterSet extends CharacterSet {
	public LowerCaseLetterICharacterSet() {
		characterSet.add('i');
	}
}
