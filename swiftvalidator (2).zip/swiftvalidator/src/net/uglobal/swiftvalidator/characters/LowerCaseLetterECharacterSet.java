package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterECharacterSet extends CharacterSet {
	public LowerCaseLetterECharacterSet() {
		characterSet.add('e');
	}
}
