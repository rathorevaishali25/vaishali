package net.uglobal.swiftvalidator.characters;

public class ColonCharacterSet extends CharacterSet {
	public ColonCharacterSet() {
		characterSet.add(':');
	}
}
