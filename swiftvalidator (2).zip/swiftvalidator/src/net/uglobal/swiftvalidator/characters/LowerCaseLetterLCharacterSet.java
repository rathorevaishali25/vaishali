package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterLCharacterSet extends CharacterSet {
	public LowerCaseLetterLCharacterSet() {
		characterSet.add('l');
	}
}
