package net.uglobal.swiftvalidator.characters;

public class DigitsWithDecimalCommaCharacterSet extends DigitsCharacterSet {
	public DigitsWithDecimalCommaCharacterSet() {
		characterSet.add(',');
	}
}
