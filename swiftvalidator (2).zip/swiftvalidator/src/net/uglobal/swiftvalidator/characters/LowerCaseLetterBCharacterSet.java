package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterBCharacterSet extends CharacterSet {
	public LowerCaseLetterBCharacterSet() {
		characterSet.add('b');
	}
}
