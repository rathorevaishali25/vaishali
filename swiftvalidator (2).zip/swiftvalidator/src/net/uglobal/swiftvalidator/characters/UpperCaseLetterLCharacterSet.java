package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterLCharacterSet extends CharacterSet {
	public UpperCaseLetterLCharacterSet() {
		characterSet.add('L');
	}
}
