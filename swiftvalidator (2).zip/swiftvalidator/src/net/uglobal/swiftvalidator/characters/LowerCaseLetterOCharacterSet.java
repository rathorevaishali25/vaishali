package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterOCharacterSet extends CharacterSet {
	public LowerCaseLetterOCharacterSet() {
		characterSet.add('o');
	}
}
