package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterBCharacterSet extends CharacterSet {
	public UpperCaseLetterBCharacterSet() {
		characterSet.add('B');
	}
}
