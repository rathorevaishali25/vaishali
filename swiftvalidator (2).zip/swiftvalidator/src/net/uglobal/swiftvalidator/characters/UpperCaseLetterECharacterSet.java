package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterECharacterSet extends CharacterSet {
	public UpperCaseLetterECharacterSet() {
		characterSet.add('E');
	}
}
