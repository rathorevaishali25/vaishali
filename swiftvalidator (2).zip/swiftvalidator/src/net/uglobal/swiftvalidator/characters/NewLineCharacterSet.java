package net.uglobal.swiftvalidator.characters;

public class NewLineCharacterSet extends CharacterSet {
	public NewLineCharacterSet() {
		//		characterSet.add('\r');
		characterSet.add('\n');
	}
}
