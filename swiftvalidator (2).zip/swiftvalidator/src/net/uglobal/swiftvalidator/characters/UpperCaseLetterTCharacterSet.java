package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterTCharacterSet extends CharacterSet {
	public UpperCaseLetterTCharacterSet() {
		characterSet.add('T');
	}
}
