package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterVCharacterSet extends CharacterSet {
	public LowerCaseLetterVCharacterSet() {
		characterSet.add('v');
	}
}
