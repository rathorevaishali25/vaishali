package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterXCharacterSet extends CharacterSet {
	public LowerCaseLetterXCharacterSet() {
		characterSet.add('x');
	}
}
