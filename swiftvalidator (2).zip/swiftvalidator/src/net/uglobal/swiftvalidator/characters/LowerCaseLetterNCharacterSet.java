package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterNCharacterSet extends CharacterSet {
	public LowerCaseLetterNCharacterSet() {
		characterSet.add('n');
	}
}
