package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterCCharacterSet extends CharacterSet {
	public LowerCaseLetterCCharacterSet() {
		characterSet.add('c');
	}
}
