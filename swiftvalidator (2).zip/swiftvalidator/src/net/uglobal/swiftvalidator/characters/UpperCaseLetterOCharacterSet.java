package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterOCharacterSet extends CharacterSet {
	public UpperCaseLetterOCharacterSet() {
		characterSet.add('O');
	}
}
