package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterRCharacterSet extends CharacterSet {
	public LowerCaseLetterRCharacterSet() {
		characterSet.add('r');
	}
}
