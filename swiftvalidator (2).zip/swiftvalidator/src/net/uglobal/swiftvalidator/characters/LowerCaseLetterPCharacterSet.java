package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterPCharacterSet extends CharacterSet {
	public LowerCaseLetterPCharacterSet() {
		characterSet.add('p');
	}
}
