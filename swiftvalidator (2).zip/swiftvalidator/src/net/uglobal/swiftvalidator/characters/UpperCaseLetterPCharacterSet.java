package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterPCharacterSet extends CharacterSet {
	public UpperCaseLetterPCharacterSet() {
		characterSet.add('P');
	}
}
