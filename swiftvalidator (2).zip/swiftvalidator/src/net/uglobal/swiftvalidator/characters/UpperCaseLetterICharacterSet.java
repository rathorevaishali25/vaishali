package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterICharacterSet extends CharacterSet {
	public UpperCaseLetterICharacterSet() {
		characterSet.add('I');
	}
}
