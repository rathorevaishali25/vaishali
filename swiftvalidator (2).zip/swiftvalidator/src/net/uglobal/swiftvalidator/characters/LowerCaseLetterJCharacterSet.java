package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterJCharacterSet extends CharacterSet {
	public LowerCaseLetterJCharacterSet() {
		characterSet.add('j');
	}
}
