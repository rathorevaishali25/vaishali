package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterUCharacterSet extends CharacterSet {
	public LowerCaseLetterUCharacterSet() {
		characterSet.add('u');
	}
}
