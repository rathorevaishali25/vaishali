package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterFCharacterSet extends CharacterSet {
	public UpperCaseLetterFCharacterSet() {
		characterSet.add('F');
	}
}
