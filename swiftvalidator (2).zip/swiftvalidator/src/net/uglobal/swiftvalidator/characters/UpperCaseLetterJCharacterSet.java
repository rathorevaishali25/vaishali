package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterJCharacterSet extends CharacterSet {
	public UpperCaseLetterJCharacterSet() {
		characterSet.add('J');
	}
}
