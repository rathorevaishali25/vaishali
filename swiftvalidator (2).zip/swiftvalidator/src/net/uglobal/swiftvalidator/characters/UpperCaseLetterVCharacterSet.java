package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterVCharacterSet extends CharacterSet {
	public UpperCaseLetterVCharacterSet() {
		characterSet.add('V');
	}
}
