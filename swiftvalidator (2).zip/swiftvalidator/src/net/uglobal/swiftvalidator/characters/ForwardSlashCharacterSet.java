package net.uglobal.swiftvalidator.characters;

public class ForwardSlashCharacterSet extends CharacterSet {
	public ForwardSlashCharacterSet() {
		characterSet.add('/');
	}
}
