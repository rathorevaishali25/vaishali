package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterHCharacterSet extends CharacterSet {
	public LowerCaseLetterHCharacterSet() {
		characterSet.add('h');
	}
}
