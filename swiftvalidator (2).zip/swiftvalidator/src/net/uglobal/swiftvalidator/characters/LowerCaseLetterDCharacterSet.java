package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterDCharacterSet extends CharacterSet {
	public LowerCaseLetterDCharacterSet() {
		characterSet.add('d');
	}
}
