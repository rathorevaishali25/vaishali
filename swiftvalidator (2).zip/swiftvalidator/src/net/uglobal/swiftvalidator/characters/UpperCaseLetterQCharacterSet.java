package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterQCharacterSet extends CharacterSet {
	public UpperCaseLetterQCharacterSet() {
		characterSet.add('Q');
	}
}
