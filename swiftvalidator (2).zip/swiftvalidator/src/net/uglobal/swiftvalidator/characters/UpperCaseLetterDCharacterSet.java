package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterDCharacterSet extends CharacterSet {
	public UpperCaseLetterDCharacterSet() {
		characterSet.add('D');
	}
}
