package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterSCharacterSet extends CharacterSet {
	public UpperCaseLetterSCharacterSet() {
		characterSet.add('S');
	}
}
