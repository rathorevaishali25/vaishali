package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterXCharacterSet extends CharacterSet {
	public UpperCaseLetterXCharacterSet() {
		characterSet.add('X');
	}
}
