package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterUCharacterSet extends CharacterSet {
	public UpperCaseLetterUCharacterSet() {
		characterSet.add('U');
	}
}
