package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterNCharacterSet extends CharacterSet {
	public UpperCaseLetterNCharacterSet() {
		characterSet.add('N');
	}
}
