package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterACharacterSet extends CharacterSet {
	public UpperCaseLetterACharacterSet() {
		characterSet.add('A');
	}
}
