package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterQCharacterSet extends CharacterSet {
	public LowerCaseLetterQCharacterSet() {
		characterSet.add('q');
	}
}
