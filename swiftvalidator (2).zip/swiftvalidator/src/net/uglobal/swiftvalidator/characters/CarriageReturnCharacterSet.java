package net.uglobal.swiftvalidator.characters;

public class CarriageReturnCharacterSet extends CharacterSet {
	public CarriageReturnCharacterSet() {
		characterSet.add('\r');
	}
}
