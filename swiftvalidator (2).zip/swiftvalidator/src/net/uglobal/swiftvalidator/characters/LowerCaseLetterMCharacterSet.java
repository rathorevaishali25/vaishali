package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterMCharacterSet extends CharacterSet {
	public LowerCaseLetterMCharacterSet() {
		characterSet.add('m');
	}
}
