package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterWCharacterSet extends CharacterSet {
	public UpperCaseLetterWCharacterSet() {
		characterSet.add('W');
	}
}
