package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterACharacterSet extends CharacterSet {
	public LowerCaseLetterACharacterSet() {
		characterSet.add('a');
	}
}
