package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterHCharacterSet extends CharacterSet {
	public UpperCaseLetterHCharacterSet() {
		characterSet.add('H');
	}
}
