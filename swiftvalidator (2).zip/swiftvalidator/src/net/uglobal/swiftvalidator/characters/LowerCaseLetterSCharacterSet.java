package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterSCharacterSet extends CharacterSet {
	public LowerCaseLetterSCharacterSet() {
		characterSet.add('s');
	}
}
