package net.uglobal.swiftvalidator.characters;

public class DigitsCharacterSet extends CharacterSet {
	public DigitsCharacterSet() {
		characterSet.add('0');
		characterSet.add('1');
		characterSet.add('2');
		characterSet.add('3');
		characterSet.add('4');
		characterSet.add('5');
		characterSet.add('6');
		characterSet.add('7');
		characterSet.add('8');
		characterSet.add('9');

	}
}
