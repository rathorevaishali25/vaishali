package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterGCharacterSet extends CharacterSet {
	public LowerCaseLetterGCharacterSet() {
		characterSet.add('g');
	}
}
