package net.uglobal.swiftvalidator.characters;

public class SpaceCharacterSet extends CharacterSet {
	public SpaceCharacterSet() {
		characterSet.add(' ');
	}
}
