package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterMCharacterSet extends CharacterSet {
	public UpperCaseLetterMCharacterSet() {
		characterSet.add('M');
	}
}
