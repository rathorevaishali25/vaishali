package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterYCharacterSet extends CharacterSet {
	public LowerCaseLetterYCharacterSet() {
		characterSet.add('y');
	}
}
