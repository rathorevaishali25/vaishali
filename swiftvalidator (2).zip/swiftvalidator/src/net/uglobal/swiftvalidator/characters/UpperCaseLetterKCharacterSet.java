package net.uglobal.swiftvalidator.characters;

public class UpperCaseLetterKCharacterSet extends CharacterSet {
	public UpperCaseLetterKCharacterSet() {
		characterSet.add('K');
	}
}
