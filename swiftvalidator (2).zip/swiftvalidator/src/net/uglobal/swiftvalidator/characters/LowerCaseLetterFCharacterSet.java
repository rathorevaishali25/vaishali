package net.uglobal.swiftvalidator.characters;

public class LowerCaseLetterFCharacterSet extends CharacterSet {
	public LowerCaseLetterFCharacterSet() {
		characterSet.add('f');
	}
}
