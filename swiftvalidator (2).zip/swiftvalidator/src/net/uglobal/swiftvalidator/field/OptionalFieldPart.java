package net.uglobal.swiftvalidator.field;

public class OptionalFieldPart extends AbstractFieldPart implements FieldPart {

	public OptionalFieldPart(String s) {
		super(s);
	}

}
