package net.uglobal.swiftvalidator.field;

public enum FieldLengthType {
	MaxLength, FixedLength, MinMaxLength, MultiLinesLength
}
