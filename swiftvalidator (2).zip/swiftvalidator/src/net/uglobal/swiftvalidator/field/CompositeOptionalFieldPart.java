package net.uglobal.swiftvalidator.field;

public class CompositeOptionalFieldPart extends AbstractFieldPart implements FieldPart {

	public CompositeOptionalFieldPart(String s) {
		super(s);
	}

}
