package net.uglobal.swiftvalidator.field;

public class MandatoryFieldPart extends AbstractFieldPart implements FieldPart {

	public MandatoryFieldPart(String s) {
		super(s);
	}

}
