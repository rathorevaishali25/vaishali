package net.uglobal.swiftvalidator.field;

public enum FieldPartType {
	MANDATORY, OPTIONAL, COMPOSITE_OPTIONAL;
}
