package net.uglobal.swiftvalidator.xml.beans;

public class MT203 extends MTMessage {

}
