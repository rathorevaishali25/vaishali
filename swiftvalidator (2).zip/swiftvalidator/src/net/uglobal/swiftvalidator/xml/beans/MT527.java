package net.uglobal.swiftvalidator.xml.beans;

public class MT527 extends MTMessage {

}
