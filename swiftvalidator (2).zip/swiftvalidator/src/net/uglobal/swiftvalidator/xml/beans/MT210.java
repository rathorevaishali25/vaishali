package net.uglobal.swiftvalidator.xml.beans;

public class MT210 extends MTMessage {

}
