package net.uglobal.swiftvalidator.xml.beans;

public class MT303 extends MTMessage {

}
