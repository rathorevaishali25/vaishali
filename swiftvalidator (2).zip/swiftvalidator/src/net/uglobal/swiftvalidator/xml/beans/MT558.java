package net.uglobal.swiftvalidator.xml.beans;

public class MT558 extends MTMessage {

}
