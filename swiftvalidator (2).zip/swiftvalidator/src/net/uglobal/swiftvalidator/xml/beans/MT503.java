package net.uglobal.swiftvalidator.xml.beans;

public class MT503 extends MTMessage {

}
