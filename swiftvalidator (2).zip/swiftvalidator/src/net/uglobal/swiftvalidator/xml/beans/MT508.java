package net.uglobal.swiftvalidator.xml.beans;

public class MT508 extends MTMessage {

}
