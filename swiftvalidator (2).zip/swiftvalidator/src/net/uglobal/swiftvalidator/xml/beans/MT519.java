package net.uglobal.swiftvalidator.xml.beans;

public class MT519 extends MTMessage {

}
