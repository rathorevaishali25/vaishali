package net.uglobal.swiftvalidator.xml.beans;

public class MT581 extends MTMessage {

}
