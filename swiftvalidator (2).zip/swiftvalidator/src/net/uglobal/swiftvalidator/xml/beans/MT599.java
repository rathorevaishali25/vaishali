package net.uglobal.swiftvalidator.xml.beans;

public class MT599 extends MTMessage {

}
