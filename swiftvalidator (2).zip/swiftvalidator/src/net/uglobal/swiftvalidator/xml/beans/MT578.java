package net.uglobal.swiftvalidator.xml.beans;

public class MT578 extends MTMessage {

}
