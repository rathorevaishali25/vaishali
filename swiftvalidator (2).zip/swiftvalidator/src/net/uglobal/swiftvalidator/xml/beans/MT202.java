package net.uglobal.swiftvalidator.xml.beans;

public class MT202 extends MTMessage {

}
