package net.uglobal.swiftvalidator.xml.beans;

public class MT566 extends MTMessage {

}
