package net.uglobal.swiftvalidator.xml.beans;

public class MT579 extends MTMessage {

}
