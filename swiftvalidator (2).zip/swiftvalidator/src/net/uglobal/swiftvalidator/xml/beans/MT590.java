package net.uglobal.swiftvalidator.xml.beans;

public class MT590 extends MTMessage {

}
