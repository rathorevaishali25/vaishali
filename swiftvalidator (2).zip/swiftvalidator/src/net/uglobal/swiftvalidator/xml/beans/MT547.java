package net.uglobal.swiftvalidator.xml.beans;

public class MT547 extends MTMessage {

}
