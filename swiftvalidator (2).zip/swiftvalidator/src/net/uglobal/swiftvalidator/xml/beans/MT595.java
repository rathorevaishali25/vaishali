package net.uglobal.swiftvalidator.xml.beans;

public class MT595 extends MTMessage {

}
