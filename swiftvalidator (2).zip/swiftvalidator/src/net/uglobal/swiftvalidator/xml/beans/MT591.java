package net.uglobal.swiftvalidator.xml.beans;

public class MT591 extends MTMessage {

}
