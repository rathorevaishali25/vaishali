package net.uglobal.swiftvalidator.xml.beans;

public class MT320 extends MTMessage {

}
