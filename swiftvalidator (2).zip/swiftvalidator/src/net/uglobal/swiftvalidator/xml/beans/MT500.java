package net.uglobal.swiftvalidator.xml.beans;

public class MT500 extends MTMessage {

}
