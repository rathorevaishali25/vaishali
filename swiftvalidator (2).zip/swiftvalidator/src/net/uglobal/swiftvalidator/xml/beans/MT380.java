package net.uglobal.swiftvalidator.xml.beans;

public class MT380 extends MTMessage {

}
