package net.uglobal.swiftvalidator.xml.beans;

public class MT507 extends MTMessage {

}
