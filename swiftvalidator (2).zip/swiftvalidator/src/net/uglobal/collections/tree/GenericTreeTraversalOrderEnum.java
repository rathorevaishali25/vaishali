/*
 Copyright 2010 Vivin Suresh Paliath
 Distributed under the BSD License
*/

package net.uglobal.collections.tree;

public enum GenericTreeTraversalOrderEnum {
	PRE_ORDER, POST_ORDER
}